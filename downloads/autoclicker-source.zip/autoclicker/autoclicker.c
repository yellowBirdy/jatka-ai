#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0A00
#endif
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <wchar.h>
#include "interval.h"

#define ID_VALUE 101
#define ID_UNIT 102
#define ID_START 103
#define ID_STOP 104
#define ID_PRESET 105
#define ID_F6 1
#define ID_F8 2
#define ID_TIMER 1
#define WM_WORKER_DONE (WM_APP + 1)
static HWND main_window, input, unit, preset_button, start_button, stop_button, status_label, countdown_label;
static HFONT font;
static HANDLE stop_event, worker;
static LARGE_INTEGER frequency;
static volatile LONG64 sent_count, deadline_count;
static volatile LONG last_warning;
static BOOL running, timer_ready;
static uint64_t period_us;
static unsigned generation;
typedef struct { uint64_t step; unsigned generation; BOOL simulation; } WorkerArgs;
static void status(const wchar_t *text) { SetWindowTextW(status_label, text); }
static uint64_t counter(void) { LARGE_INTEGER value; QueryPerformanceCounter(&value); return (uint64_t)value.QuadPart; }

static DWORD WINAPI click_worker(void *argument) {
    WorkerArgs args = *(WorkerArgs *)argument; free(argument);
    HANDLE timer = CreateWaitableTimerExW(NULL, NULL, 0x00000002, TIMER_ALL_ACCESS);
    if (!timer) timer = CreateWaitableTimerW(NULL, FALSE, NULL);
    DWORD result = 0;
    if (!timer) { result = 1; goto done; }
    HANDLE handles[2] = {stop_event, timer};
    uint64_t next = counter() + args.step;
    InterlockedExchange64(&deadline_count, (LONG64)next);
    for (;;) {
        if (WaitForSingleObject(stop_event, 0) == WAIT_OBJECT_0) break;
        uint64_t now = counter();
        if (now < next) {
            long double delay = (long double)(next - now) * 10000000.0L / frequency.QuadPart;
            LARGE_INTEGER due; due.QuadPart = -(LONGLONG)(delay < 1 ? 1 : delay);
            if (!SetWaitableTimer(timer, &due, 0, NULL, NULL, FALSE)) { result = 1; break; }
            DWORD wait = WaitForMultipleObjects(2, handles, FALSE, INFINITE);
            if (wait == WAIT_OBJECT_0) break;
            if (wait != WAIT_OBJECT_0 + 1) { result = 1; break; }
            continue;
        }
        if (WaitForSingleObject(stop_event, 0) == WAIT_OBJECT_0) break;
        if (args.simulation) InterlockedIncrement64(&sent_count);
        else {
            POINT point = {0};
            if (!GetCursorPos(&point)) { result = 2; break; }
            HWND under = WindowFromPoint(point);
            if (under && GetAncestor(under, GA_ROOT) == main_window) InterlockedExchange(&last_warning, 1);
            else {
                INPUT events[2] = {0}; events[0].type = events[1].type = INPUT_MOUSE;
                events[0].mi.dwFlags = MOUSEEVENTF_LEFTDOWN; events[1].mi.dwFlags = MOUSEEVENTF_LEFTUP;
                UINT sent = SendInput(2, events, (int)sizeof(INPUT));
                if (sent != 2) { if (sent == 1) SendInput(1, &events[1], (int)sizeof(INPUT)); result = 2; break; }
                InterlockedIncrement64(&sent_count); InterlockedExchange(&last_warning, 0);
            }
        }
        next = next_deadline(next, counter(), args.step);
        InterlockedExchange64(&deadline_count, (LONG64)next);
    }
    CancelWaitableTimer(timer); CloseHandle(timer);
done:
    if (result) PostMessageW(main_window, WM_WORKER_DONE, result, (LPARAM)args.generation);
    return result;
}
static void stop_clicking(const wchar_t *message) {
    if (stop_event) SetEvent(stop_event);
    if (worker) { WaitForSingleObject(worker, INFINITE); CloseHandle(worker); worker = NULL; }
    running = FALSE;
    EnableWindow(input, TRUE); EnableWindow(unit, TRUE); EnableWindow(preset_button, TRUE);
    EnableWindow(start_button, TRUE); EnableWindow(stop_button, FALSE);
    SetWindowTextW(countdown_label, L"Nie działa"); status(message);
}
static BOOL start_worker(uint64_t selected_period, BOOL simulation) {
    if (!timer_ready || !stop_event) return FALSE;
    WorkerArgs *args = malloc(sizeof(*args)); if (!args) return FALSE;
    args->step = (uint64_t)((long double)selected_period * frequency.QuadPart / 1000000.0L);
    if (args->step == 0) args->step = 1;
    args->generation = ++generation; args->simulation = simulation;
    ResetEvent(stop_event); InterlockedExchange64(&sent_count, 0); InterlockedExchange(&last_warning, 0);
    InterlockedExchange64(&deadline_count, (LONG64)(counter() + args->step));
    period_us = selected_period;
    worker = CreateThread(NULL, 0, click_worker, args, 0, NULL);
    if (!worker) { free(args); return FALSE; }
    running = TRUE; return TRUE;
}
static void start_clicking(void) {
    if (running) return;
    wchar_t wide[64] = {0}; char text[64] = {0}; GetWindowTextW(input, wide, 64);
    size_t n = wcslen(wide);
    for (size_t i = 0; i <= n; i++) text[i] = wide[i] <= 127 ? (char)wide[i] : '?';
    uint64_t selected_period; int selected = (int)SendMessageW(unit, CB_GETCURSEL, 0, 0);
    if (!parse_period_us(text, selected, &selected_period)) {
        status(L"Odstęp: 1 ms–365 dni. Tryb szybkości: 1–1000 kliknięć/s."); return;
    }
    if (!start_worker(selected_period, FALSE)) { status(L"Nie udało się uruchomić zegara. Uruchom program ponownie."); return; }
    EnableWindow(input, FALSE); EnableWindow(unit, FALSE); EnableWindow(preset_button, FALSE);
    EnableWindow(start_button, FALSE); EnableWindow(stop_button, TRUE);
    status(L"Włączony. Pierwszy klik po wybranym odstępie. F8 = STOP.");
}
static HWND control(const wchar_t *type, const wchar_t *text, DWORD style, int x, int y, int w, int h, int id) {
    HWND handle = CreateWindowExW(0,type,text,WS_CHILD|WS_VISIBLE|style,x,y,w,h,main_window,(HMENU)(INT_PTR)id,GetModuleHandleW(NULL),NULL);
    SendMessageW(handle,WM_SETFONT,(WPARAM)font,TRUE); return handle;
}
static LRESULT CALLBACK window_proc(HWND window, UINT message, WPARAM wp, LPARAM lp) {
    switch (message) {
    case WM_CREATE: {
        main_window = window;
        font = CreateFontW(-17,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
        control(L"STATIC",L"Odstęp albo liczba kliknięć na sekundę:",0,20,18,460,26,0);
        input=control(L"EDIT",L"10",WS_BORDER|WS_TABSTOP|ES_AUTOHSCROLL,20,50,180,30,ID_VALUE);
        SendMessageW(input,EM_SETLIMITTEXT,40,0);
        unit=control(L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_TABSTOP|WS_VSCROLL,215,50,255,180,ID_UNIT);
        const wchar_t *units[]={L"milisekundy",L"sekundy",L"minuty",L"godziny",L"kliknięcia / sekundę"};
        for (int i=0;i<5;i++) SendMessageW(unit,CB_ADDSTRING,0,(LPARAM)units[i]);
        SendMessageW(unit,CB_SETCURSEL,2,0);
        preset_button=control(L"BUTTON",L"Ustaw 1000 kliknięć/s",WS_TABSTOP,20,92,230,30,ID_PRESET);
        control(L"STATIC",L"Np. 10 minut, 0,5 godziny albo 1000 kliknięć/s.\r\nRzeczywista szybkość zależy od Windowsa i aplikacji.",0,20,132,460,46,0);
        start_button=control(L"BUTTON",L"START (F6)",WS_TABSTOP|BS_DEFPUSHBUTTON,20,185,210,36,ID_START);
        stop_button=control(L"BUTTON",L"STOP (F8)",WS_TABSTOP,250,185,220,36,ID_STOP);
        EnableWindow(stop_button,FALSE);
        countdown_label=control(L"STATIC",L"Nie działa",0,20,240,460,30,0);
        status_label=control(L"STATIC",L"Lewy klik w aktualnym miejscu kursora. F6: start/stop.",0,20,278,460,48,0);
        control(L"STATIC",L"Program musi pozostać uruchomiony. Nie nadrabia opóźnień serią kliknięć.",0,20,335,460,44,0);
        BOOL f6=RegisterHotKey(window,ID_F6,MOD_NOREPEAT,VK_F6),f8=RegisterHotKey(window,ID_F8,MOD_NOREPEAT,VK_F8);
        if (!f6||!f8) status(L"Skrót zajęty przez inny program. Użyj przycisków START/STOP.");
        stop_event=CreateEventW(NULL,TRUE,FALSE,NULL);
        timer_ready=stop_event&&QueryPerformanceFrequency(&frequency)&&SetTimer(window,ID_TIMER,100,NULL)!=0;
        if (!timer_ready) { EnableWindow(start_button,FALSE);status(L"Nie udało się uruchomić zegara."); }
        return 0;
    }
    case WM_COMMAND:
        if (LOWORD(wp)==ID_START) start_clicking();
        if (LOWORD(wp)==ID_STOP||LOWORD(wp)==IDCANCEL) stop_clicking(L"Zatrzymano.");
        if (LOWORD(wp)==ID_PRESET&&!running) { SetWindowTextW(input,L"1000");SendMessageW(unit,CB_SETCURSEL,4,0);status(L"Wybrano 1000 kliknięć/s. F6 rozpoczyna klikanie."); }
        return 0;
    case WM_HOTKEY:
        if (wp==ID_F8) stop_clicking(L"Zatrzymano klawiszem F8.");
        if (wp==ID_F6) { if (running) stop_clicking(L"Zatrzymano.");else start_clicking(); }
        return 0;
    case WM_WORKER_DONE:
        if ((unsigned)lp==generation) stop_clicking(wp==2?L"Windows nie przyjął kliknięcia. Program zatrzymany.":L"Błąd zegara. Program zatrzymany.");
        return 0;
    case WM_TIMER:
        if (running) {
            uint64_t now=counter(),next=(uint64_t)InterlockedCompareExchange64(&deadline_count,0,0);
            uint64_t remaining=next>now?(uint64_t)((long double)(next-now)*1000/frequency.QuadPart):0;
            wchar_t label[160];
            swprintf(label,160,L"Następny: %llu:%02llu:%02llu.%03llu | Kliknięć: %llu",(unsigned long long)(remaining/3600000),(unsigned long long)(remaining/60000%60),(unsigned long long)(remaining/1000%60),(unsigned long long)(remaining%1000),(unsigned long long)InterlockedCompareExchange64(&sent_count,0,0));
            SetWindowTextW(countdown_label,label);
            if (InterlockedCompareExchange(&last_warning,0,0)==1) status(L"Kursor jest nad tym oknem. Przesuń go na cel.");
            else if (InterlockedCompareExchange64(&sent_count,0,0)>0) status(L"Klika w miejscu kursora. F8 = STOP.");
        }
        return 0;
    case WM_POWERBROADCAST:
        if (wp==PBT_APMSUSPEND) stop_clicking(L"Zatrzymano przy uśpieniu. F6 uruchamia ponownie.");
        return TRUE;
    case WM_CLOSE: DestroyWindow(window);return 0;
    case WM_DESTROY:
        stop_clicking(L"Zamknięto.");KillTimer(window,ID_TIMER);
        UnregisterHotKey(window,ID_F6);UnregisterHotKey(window,ID_F8);
        if (stop_event) CloseHandle(stop_event);
        if (font) DeleteObject(font);
        PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(window,message,wp,lp);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE previous,PWSTR command,int show) {
    (void)previous;SetProcessDPIAware();
    WNDCLASSW cls={0};cls.lpfnWndProc=window_proc;cls.hInstance=instance;cls.lpszClassName=L"IntervalClicker";
    cls.hCursor=LoadCursor(NULL,IDC_ARROW);cls.hbrBackground=(HBRUSH)(INT_PTR)(COLOR_WINDOW+1);
    if (!RegisterClassW(&cls)) return 1;
    HWND window=CreateWindowExW(0,cls.lpszClassName,L"Autoclicker — odstęp i do 1000 kliknięć/s",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,515,430,NULL,NULL,instance,NULL);
    if (!window) return 1;
    if (wcscmp(command,L"--self-test")==0) {
        BOOL ok=timer_ready&&IsWindow(input)&&IsWindow(unit)&&SendMessageW(unit,CB_GETCURSEL,0,0)==2;
        start_clicking();ok=ok&&running&&period_us==600000000;
        stop_clicking(L"Test");ok=ok&&!running;
        uint64_t fast;ok=ok&&parse_period_us("1000",4,&fast)&&fast==1000;
        /* Exercise high-resolution scheduling with a counter only: no SendInput. */
        if (ok&&start_worker(1000,TRUE)) { Sleep(200);stop_clicking(L"Test");LONG64 ticks=InterlockedCompareExchange64(&sent_count,0,0);ok=ticks>0&&ticks<1000; } else ok=FALSE;
        DestroyWindow(window);return ok?0:2;
    }
    ShowWindow(window,show);UpdateWindow(window);MSG message;
    while (GetMessageW(&message,NULL,0,0)>0) if (!IsDialogMessageW(window,&message)) { TranslateMessage(&message);DispatchMessageW(&message); }
    return 0;
}
