#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include "interval.h"

#define ID_VALUE 101
#define ID_UNIT 102
#define ID_START 103
#define ID_STOP 104
#define ID_F6 1
#define ID_F8 2
#define ID_TIMER 1
static HWND main_window, input, unit, start_button, stop_button, status_label, countdown_label;
static HFONT font;
static ClickClock click_clock;
static uint64_t count;
static BOOL timer_ready;
static ULONGLONG last_paint;
static void status(const wchar_t *text) { SetWindowTextW(status_label, text); }
static void stop_clicking(const wchar_t *message) {
    clock_stop(&click_clock);
    EnableWindow(input, TRUE); EnableWindow(unit, TRUE);
    EnableWindow(start_button, TRUE); EnableWindow(stop_button, FALSE);
    SetWindowTextW(countdown_label, L"Nie działa"); status(message);
}
static void start_clicking(void) {
    if (!timer_ready) { status(L"Zegar niedostępny. Uruchom program ponownie."); return; }
    wchar_t wide[64]; char text[64];
    GetWindowTextW(input, wide, 64);
    size_t n = wcslen(wide);
    for (size_t i = 0; i <= n; i++) text[i] = wide[i] <= 127 ? (char)wide[i] : '?';
    uint64_t interval;
    int selected = (int)SendMessageW(unit, CB_GETCURSEL, 0, 0);
    if (!parse_interval(text, selected, &interval)) {
        status(L"Wpisz poprawny odstęp: od 1 ms do 365 dni."); return;
    }
    clock_start(&click_clock, interval, GetTickCount64()); count = 0;
    EnableWindow(input, FALSE); EnableWindow(unit, FALSE);
    EnableWindow(start_button, FALSE); EnableWindow(stop_button, TRUE);
    status(L"Włączony. Pierwszy klik po wybranym odstępie. F8 = STOP.");
}
static HWND control(const wchar_t *type, const wchar_t *text, DWORD style, int x, int y, int w, int h, int id) {
    HWND handle = CreateWindowExW(0, type, text, WS_CHILD | WS_VISIBLE | style, x, y, w, h, main_window, (HMENU)(INT_PTR)id, GetModuleHandleW(NULL), NULL);
    SendMessageW(handle, WM_SETFONT, (WPARAM)font, TRUE); return handle;
}
static LRESULT CALLBACK window_proc(HWND window, UINT message, WPARAM wp, LPARAM lp) {
    switch (message) {
    case WM_CREATE:
        main_window = window;
        font = CreateFontW(-17,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
        control(L"STATIC", L"Odstęp między kliknięciami:", 0, 20, 20, 440, 25, 0);
        input = control(L"EDIT", L"10", WS_BORDER | WS_TABSTOP | ES_AUTOHSCROLL, 20, 52, 190, 30, ID_VALUE);
        SendMessageW(input, EM_SETLIMITTEXT, 40, 0);
        unit = control(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP | WS_VSCROLL, 225, 52, 235, 150, ID_UNIT);
        const wchar_t *units[] = {L"milisekundy", L"sekundy", L"minuty", L"godziny"};
        for (int i = 0; i < 4; i++) SendMessageW(unit, CB_ADDSTRING, 0, (LPARAM)units[i]);
        SendMessageW(unit, CB_SETCURSEL, 2, 0);
        control(L"STATIC", L"Przykład: 10 + minuty = jeden klik co 10 minut.\r\nMożesz wpisać też ułamek, np. 0,5 godziny.", 0, 20, 96, 460, 50, 0);
        start_button = control(L"BUTTON", L"START  (F6)", WS_TABSTOP | BS_DEFPUSHBUTTON, 20, 155, 210, 36, ID_START);
        stop_button = control(L"BUTTON", L"STOP  (F8)", WS_TABSTOP, 250, 155, 210, 36, ID_STOP);
        EnableWindow(stop_button, FALSE);
        countdown_label = control(L"STATIC", L"Nie działa", 0, 20, 210, 455, 30, 0);
        status_label = control(L"STATIC", L"Lewy klik w aktualnym miejscu kursora. F6: start/stop.", 0, 20, 245, 460, 45, 0);
        control(L"STATIC", L"Program nie musi mieć aktywnego okna. Najkrótszy rzeczywisty odstęp wynosi około 20 ms.", 0, 20, 295, 460, 45, 0);
        BOOL f6 = RegisterHotKey(window, ID_F6, MOD_NOREPEAT, VK_F6);
        BOOL f8 = RegisterHotKey(window, ID_F8, MOD_NOREPEAT, VK_F8);
        if (!f6 || !f8)
            status(L"Nie udało się zarejestrować skrótu. Użyj przycisków START/STOP.");
        timer_ready = SetTimer(window, ID_TIMER, 20, NULL) != 0;
        if (!timer_ready) {
            EnableWindow(start_button, FALSE); status(L"Nie udało się uruchomić zegara programu.");
        }
        return 0;
    case WM_COMMAND:
        if (LOWORD(wp) == ID_START && !click_clock.running) start_clicking();
        if (LOWORD(wp) == ID_STOP || LOWORD(wp) == IDCANCEL) stop_clicking(L"Zatrzymano.");
        return 0;
    case WM_HOTKEY:
        if (wp == ID_F8) stop_clicking(L"Zatrzymano klawiszem F8.");
        if (wp == ID_F6) { if (click_clock.running) stop_clicking(L"Zatrzymano."); else start_clicking(); }
        return 0;
    case WM_KEYDOWN:
        if (wp == VK_ESCAPE) stop_clicking(L"Zatrzymano.");
        return 0;
    case WM_TIMER: {
        ULONGLONG now = GetTickCount64();
        if (!click_clock.running) return 0;
        if (clock_due(&click_clock, now)) {
            POINT point; GetCursorPos(&point);
            HWND under = WindowFromPoint(point);
            if (under && GetAncestor(under, GA_ROOT) == window) {
                status(L"Pominięto klik we własnym oknie. Przesuń kursor na cel.");
            } else {
                INPUT events[2] = {0};
                events[0].type = events[1].type = INPUT_MOUSE;
                events[0].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
                events[1].mi.dwFlags = MOUSEEVENTF_LEFTUP;
                UINT sent = SendInput(2, events, sizeof(INPUT));
                if (sent != 2) {
                    if (sent == 1) SendInput(1, &events[1], sizeof(INPUT));
                    stop_clicking(L"Windows nie przyjął kliknięcia. Program zatrzymany."); return 0;
                }
                count++; status(L"Kliknięto. F8 zatrzymuje program.");
            }
        }
        if (now - last_paint >= 100) {
            last_paint = now;
            uint64_t remaining = click_clock.next > now ? click_clock.next - now : 0;
            wchar_t label[128];
            swprintf(label,128,L"Następny klik za %llu:%02llu:%02llu.%03llu  |  Kliknięć: %llu",
                (unsigned long long)(remaining/3600000), (unsigned long long)(remaining/60000%60),
                (unsigned long long)(remaining/1000%60), (unsigned long long)(remaining%1000), (unsigned long long)count);
            SetWindowTextW(countdown_label,label);
        }
        return 0;
    }
    case WM_POWERBROADCAST:
        if (wp == PBT_APMSUSPEND) stop_clicking(L"Zatrzymano przy uśpieniu komputera. F6 uruchamia ponownie.");
        return TRUE;
    case WM_CLOSE: DestroyWindow(window); return 0;
    case WM_DESTROY:
        clock_stop(&click_clock); KillTimer(window, ID_TIMER);
        UnregisterHotKey(window, ID_F6); UnregisterHotKey(window, ID_F8);
        if (font) DeleteObject(font); PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(window,message,wp,lp);
}
int WINAPI wWinMain(HINSTANCE instance, HINSTANCE previous, PWSTR command, int show) {
    (void)previous;
    SetProcessDPIAware();
    WNDCLASSW cls = {0}; cls.lpfnWndProc = window_proc; cls.hInstance = instance;
    cls.lpszClassName = L"IntervalClicker"; cls.hCursor = LoadCursor(NULL, IDC_ARROW);
    cls.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    if (!RegisterClassW(&cls)) return 1;
    HWND window = CreateWindowExW(0, cls.lpszClassName, L"Autoclicker — dowolny odstęp", WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
            CW_USEDEFAULT,CW_USEDEFAULT,510,395,NULL,NULL,instance,NULL);
    if (!window) return 1;
    if (wcscmp(command, L"--self-test") == 0) {
        BOOL ok = timer_ready && IsWindow(input) && IsWindow(unit) && IsWindow(start_button) && IsWindow(stop_button);
        ok = ok && SendMessageW(unit, CB_GETCURSEL, 0, 0) == 2;
        start_clicking();
        ok = ok && click_clock.running && click_clock.interval == 600000 && count == 0;
        stop_clicking(L"Test");
        ok = ok && !click_clock.running;
        DestroyWindow(window);
        return ok ? 0 : 2;
    }
    ShowWindow(window,show); UpdateWindow(window);
    MSG message;
    while (GetMessageW(&message,NULL,0,0)>0) { if (!IsDialogMessageW(window,&message)) { TranslateMessage(&message); DispatchMessageW(&message); } }
    return 0;
}
