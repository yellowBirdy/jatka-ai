#ifndef CLICK_INTERVAL_H
#define CLICK_INTERVAL_H
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define MAX_INTERVAL_MS UINT64_C(31536000000)
static bool parse_interval(const char *text, int unit, uint64_t *milliseconds) {
    static const uint64_t units[] = {1, 1000, 60000, 3600000};
    if (!text || !milliseconds || unit < 0 || unit > 3) return false;
    size_t n = strlen(text);
    if (n == 0 || n >= 64) return false;
    char normalized[64];
    for (size_t i = 0; i <= n; i++) {
        char c = text[i];
        if (c && !((c >= '0' && c <= '9') || c == '.' || c == ',' || c == ' ')) return false;
        normalized[i] = c == ',' ? '.' : c;
    }
    char *end;
    long double value = strtold(normalized, &end);
    if (end == normalized) return false;
    while (*end == ' ') end++;
    long double result = value * units[unit];
    if (*end || !isfinite(result) || result < 1.0L - 1e-12L || result > MAX_INTERVAL_MS) return false;
    *milliseconds = (uint64_t)(result + 0.5L);
    return true;
}
typedef struct { bool running; uint64_t interval, next; } ClickClock;
static void clock_start(ClickClock *clock, uint64_t interval, uint64_t now) {
    clock->interval = interval; clock->next = now + interval; clock->running = true;
}
static void clock_stop(ClickClock *clock) { clock->running = false; }
static bool clock_due(ClickClock *clock, uint64_t now) {
    if (!clock->running || now < clock->next) return false;
    clock->next = now + clock->interval;
    return true;
}
#endif
