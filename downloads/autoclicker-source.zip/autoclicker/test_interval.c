#include "interval.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
    uint64_t ms = 0;
    assert(parse_interval("10", 2, &ms) && ms == 600000);
    assert(parse_interval("1.5", 1, &ms) && ms == 1500);
    assert(parse_interval("1,5", 1, &ms) && ms == 1500);
    assert(parse_interval("0.001", 1, &ms) && ms == 1);
    assert(parse_interval("0.25", 3, &ms) && ms == 900000);
    assert(parse_interval("8760", 3, &ms) && ms == MAX_INTERVAL_MS);
    const char *bad[] = {"", "0", "-1", "abc", "1e9", "1.2.3", "1,2,3", "NaN", "0.1"};
    for (size_t i = 0; i < sizeof(bad)/sizeof(bad[0]); i++) assert(!parse_interval(bad[i], 0, &ms));
    assert(!parse_interval("8761", 3, &ms));
    assert(!parse_interval("10", 4, &ms));
    ClickClock clock = {0};
    clock_start(&clock, 600000, 100);
    assert(!clock_due(&clock, 100));
    assert(!clock_due(&clock, 600099));
    assert(clock_due(&clock, 600100));
    assert(!clock_due(&clock, 600100));
    assert(clock_due(&clock, 2400100)); /* sleep/lag does not queue missed clicks */
    assert(!clock_due(&clock, 2400100));
    clock_stop(&clock);
    assert(!clock_due(&clock, 9999999));
    uint64_t period;
    assert(parse_period_us("1000", 4, &period) && period == 1000);
    assert(parse_period_us("1", 4, &period) && period == 1000000);
    assert(parse_period_us("10", 2, &period) && period == 600000000);
    assert(!parse_period_us("1001", 4, &period));
    assert(!parse_period_us("1.5", 4, &period));
    assert(!parse_period_us("0", 4, &period));
    uint64_t deadline = 1000;
    unsigned ticks = 0;
    for (uint64_t now = 1; now <= 1000000; now++) if (now >= deadline) { ticks++; deadline = next_deadline(deadline, now, 1000); }
    assert(ticks == 1000);
    assert(next_deadline(1000, 1000000, 1000) == 1001000); /* no delayed burst */
    puts("PASS: arbitrary intervals, decimal units, validation, ten-minute scheduling and stop.");
}
