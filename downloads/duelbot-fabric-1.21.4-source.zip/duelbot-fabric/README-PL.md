# Private Duel Bot 1.1 — Fabric 1.21.4

Osobny mod klienta Minecrafta do uzgodnionych prywatnych pojedynków.

## Instalacja i sterowanie
W Minecraft Java 1.21.4 z Fabric Loader 0.16.10+ umieść JAR moda i Fabric API
0.119.2+1.21.4 w `.minecraft/mods`. Usuń starszy JAR Duel Bota, aby nie ładować dwóch wersji.
**R** — ON/OFF, **Y** — ustawienia (klawisze zmienisz w Sterowaniu).
Domyślnie wyłączony; po wyjściu ze świata wyłącza się automatycznie.

## Wybór przedmiotów i szybkości
Panel Y pozwala wybierać osobno każdy rodzaj miecza, topora i buławę, a także aktualnie
trzymany przedmiot niestandardowy. Funkcja startuje wyłącznie, jeśli przedmiot w głównej
ręce jest dozwolony. Tempo 1–20 ataków/s to limit maksymalny, nie obietnica takiej liczby
pełnych trafień. Dla zwykłych ataków opcja pełnego odnowienia broni jest domyślnie ON.
Większa liczba ataków przy niepełnym cooldownie nie zwiększa automatycznie obrażeń.
Ustawienia zapisują się w `.minecraft/config/duelbot.json`.

## Shield break
Opcja szuka dozwolonego topora na pasku szybkiego dostępu. Gdy widoczny gracz w zasięgu
blokuje tarczą, przełącza na topór, czeka na odnowienie (jeśli włączone), atakuje i wraca
do poprzedniego slotu. Nie zabiera przedmiotów z dalszych slotów ekwipunku.

## Stun slam
Potrzebne: założona elytra, spadanie i dozwolona buława na pasku. Jeśli cel blokuje,
potrzebny jest również dozwolony topór. Mod atakuje toporem, przełącza na buławę,
czeka skonfigurowaną liczbę ticków i uderza buławą, dopóki nadal spadasz i cel pozostaje
widoczny w zasięgu. Bez tarczy przechodzi od razu do buławy.
Przerwa respektuje także maksymalny limit ataków/s. Dotyczy zwykłych ataków odpowiednim
przedmiotem: mod nie przenosi atrybutów między broniami, nie dodaje wysokości spadania
ani nie wymusza pełnych obrażeń po szybkiej zmianie. To rozlicza serwer.
Mod sam nie steruje elytrą ani ruchem gracza.

## Płynność i przerwanie sekwencji
Mod nie ustawia lokalnego yaw/pitch, kierunku ciała, prędkości ani wejścia klawiatury.
Obrót wymagany do ataku i przywrócenie kierunku są wysyłane do serwera; kamera klienta
pozostaje pod kontrolą gracza. Sekwencja przerywa się po utracie celu, lądowaniu,
otwarciu menu lub wyłączeniu. Ręczna zmiana slotu jest zachowywana.
Widoczni, żywi gracze w zasięgu maks. 3 bloków; obserwatorzy, creative i członkowie
tej samej drużyny są pomijani. Serwer może odrzucać automatyczne akcje.

## Budowanie
JDK 21, `gradlew.bat build` lub `./gradlew build`. Gotowy mod:
`build/libs/duelbot-1.21.4-1.1.0.jar`. Repozytorium zawiera workflow budowania i testy JUnit.
