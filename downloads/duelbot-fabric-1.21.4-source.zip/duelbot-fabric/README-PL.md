# Private Duel Bot — Fabric 1.21.4

Źródła moda klienckiego. To nie jest datapack ani samodzielny EXE.

## Działanie
- Domyślnie wyłączony. Klawisz **R** przełącza ON/OFF (zmienisz go w Sterowaniu).
- Wybiera najbliższego widocznego gracza w standardowym zasięgu, maksymalnie 3 bloki od oka do hitboxa.
- Pomija obserwatorów, graczy kreatywnych i członków tej samej drużyny.
- Respektuje pełne odnowienie ataku; nie atakuje podczas używania przedmiotu ani w otwartym menu.
- Wysyła obrót, wykonuje zwykły `attackEntity` i zamach ręką, po czym przywraca obrót w `finally`.
- Obrót i powrót następują w jednym ticku, więc nie jest to płynna animacja obrotu kamery.
- Wyłącza się po odłączeniu. Nie obsługuje komend zadawania obrażeń ani obchodzenia zabezpieczeń serwera.

## Zbudowanie JAR-a
Wymagany **JDK 21** i internet. Rozpakuj projekt i uruchom `BUDUJ-WINDOWS.bat`,
albo `gradlew.bat build` (Windows) / `./gradlew build` (Linux/macOS).
JAR po udanej kompilacji: `build/libs/duelbot-1.21.4-1.0.0.jar`.

Alternatywnie wgraj projekt jako osobne repozytorium GitHub. Workflow `Build Fabric mod`
uruchomi kompilację i testy; wynik pobierzesz z Actions → zakończony przebieg → Artifacts.

## Instalacja
Zainstaluj Minecraft Java **1.21.4**, Fabric Loader **0.16.10 lub nowszy** oraz Fabric API
**0.119.2+1.21.4**. Umieść gotowy JAR i Fabric API w folderze `.minecraft/mods` klienta.
Serwer nie potrzebuje tego moda. Używaj w uzgodnionych prywatnych pojedynkach.

## Stan weryfikacji
Dołączono testy JUnit matematyki obrotu. W środowisku przygotowania źródeł repozytorium
maven.fabricmc.net zwracało HTTP 403, więc pełna kompilacja, testy JUnit i uruchomienie
Minecrafta nie zostały potwierdzone. ZIP zawiera źródła, nie gotowy/skompilowany mod.
