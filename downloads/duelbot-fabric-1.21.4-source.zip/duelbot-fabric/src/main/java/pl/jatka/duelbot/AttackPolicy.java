package pl.jatka.duelbot;

final class AttackPolicy {
    private AttackPolicy() {}
    static int boundedCps(int cps) { return Math.max(1, Math.min(20, cps)); }
    static long intervalMillis(int cps) { return (1000L + boundedCps(cps) - 1) / boundedCps(cps); }
    static boolean ready(long now, long nextAttack, float cooldown, boolean respectCooldown) {
        return now >= nextAttack && (!respectCooldown || cooldown >= 1.0F);
    }
    static boolean fallingSlam(boolean elytra, boolean grounded, double verticalSpeed) {
        return elytra && !grounded && verticalSpeed < -0.08;
    }
    static int slotAfterCancel(int original, int expected, int current) {
        return original >= 0 && original < 9 && current == expected ? original : current;
    }
    static int boundedDelay(int ticks) { return Math.max(1, Math.min(10, ticks)); }
}
