package pl.jatka.duelbot;

final class AimMath {
    private AimMath() {}
    record Angles(float yaw, float pitch) {}
    static Angles facing(double dx, double dy, double dz) {
        return new Angles((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0),
                (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz))));
    }
    static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
