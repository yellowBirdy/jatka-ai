package pl.jatka.duelbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import java.util.UUID;

public final class DuelBotClient implements ClientModInitializer {
    private boolean enabled;
    private KeyBinding toggle, settings;
    private DuelConfig config;
    private long nextAttack;
    private int tick, stageTick, originalSlot = -1, expectedSlot = -1, maceSlot = -1;
    private UUID pendingTarget;
    private Stage stage = Stage.IDLE;
    private boolean combo;
    private enum Stage { IDLE, AXE, MACE, RESTORE }

    @Override public void onInitializeClient() {
        config = DuelConfig.load();
        toggle = KeyBindingHelper.registerKeyBinding(new KeyBinding("Duel Bot: wlacz / wylacz", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "Private Duel Bot"));
        settings = KeyBindingHelper.registerKeyBinding(new KeyBinding("Duel Bot: ustawienia", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Y, "Private Duel Bot"));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> { enabled = false; clearSequence(); nextAttack = 0; });
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }
    private void tick(MinecraftClient client) {
        tick++;
        ClientPlayerEntity self = client.player;
        if (self == null || client.world == null || client.interactionManager == null) { enabled = false; clearSequence(); return; }
        while (settings.wasPressed()) {
            cancel(self);
            if (client.currentScreen instanceof DuelSettingsScreen screen) screen.close();
            else client.setScreen(new DuelSettingsScreen(client.currentScreen, config, false));
        }
        while (toggle.wasPressed()) {
            enabled = !enabled;
            if (!enabled) cancel(self);
            self.sendMessage(Text.literal("Duel Bot: " + (enabled ? "ON (Y: ustawienia)" : "OFF")), true);
        }
        if (!enabled || client.currentScreen != null || client.isPaused() || !self.isAlive()
                || self.isSpectator() || self.isUsingItem()) { cancel(self); return; }
        long now = System.nanoTime() / 1_000_000L;
        if (stage != Stage.IDLE) { advance(client, self, now); return; }
        if (!allowed(self.getMainHandStack())) return;
        PlayerEntity target = findTarget(client, self);
        if (target == null) return;
        boolean slam = config.stunSlam && falling(self);
        int axe = findAxe(self), mace = findMace(self);
        if (((config.shieldBreak && target.isBlocking()) || slam) && (axe >= 0 || (slam && !target.isBlocking())) && (!slam || mace >= 0)) {
            if (now < nextAttack) return;
            originalSlot = self.getInventory().selectedSlot;
            pendingTarget = target.getUuid();
            maceSlot = mace;
            combo = slam;
            setSlot(self, slam && !target.isBlocking() ? mace : axe);
            stage = slam && !target.isBlocking() ? Stage.MACE : Stage.AXE; stageTick = tick;
            return;
        }
        if (AttackPolicy.ready(now, nextAttack, self.getAttackCooldownProgress(0), config.respectCooldown)) hit(client, self, target, now);
    }
    private void advance(MinecraftClient client, ClientPlayerEntity self, long now) {
        if (self.getInventory().selectedSlot != expectedSlot) { clearSequence(); return; }
        if (tick - stageTick > 60) { cancel(self); return; }
        if (stage == Stage.RESTORE) { if (tick > stageTick) cancel(self); return; }
        PlayerEntity target = client.world.getPlayerByUuid(pendingTarget);
        if (!validTarget(self, target) || (combo && !falling(self))) { cancel(self); return; }
        if (stage == Stage.AXE) {
            if (tick - stageTick < 2 || !AttackPolicy.ready(now, nextAttack, self.getAttackCooldownProgress(0), config.respectCooldown)) return;
            hit(client, self, target, now);
            if (combo) { setSlot(self, maceSlot); stage = Stage.MACE; } else stage = Stage.RESTORE;
            stageTick = tick;
        } else if (stage == Stage.MACE && tick - stageTick >= config.maceDelayTicks && now >= nextAttack) {
            // Ordinary mace attack after the configured swap delay. The server determines actual cooldown damage.
            hit(client, self, target, now);
            stage = Stage.RESTORE; stageTick = tick;
        }
    }
    private boolean allowed(ItemStack stack) { return !stack.isEmpty() && config.allowedItems.contains(Registries.ITEM.getId(stack.getItem()).toString()); }
    private int findAxe(ClientPlayerEntity self) {
        for (int i = 0; i < 9; i++) if (self.getInventory().getStack(i).isIn(ItemTags.AXES) && allowed(self.getInventory().getStack(i))) return i;
        return -1;
    }
    private int findMace(ClientPlayerEntity self) {
        for (int i = 0; i < 9; i++) if (self.getInventory().getStack(i).isOf(Items.MACE) && allowed(self.getInventory().getStack(i))) return i;
        return -1;
    }
    private static boolean falling(ClientPlayerEntity self) {
        return AttackPolicy.fallingSlam(self.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA), self.isOnGround(), self.getVelocity().y);
    }
    private PlayerEntity findTarget(MinecraftClient client, ClientPlayerEntity self) {
        PlayerEntity best = null; double distance = Double.POSITIVE_INFINITY;
        for (PlayerEntity other : client.world.getPlayers()) if (validTarget(self, other)) {
            double d = self.getEyePos().squaredDistanceTo(closestPoint(self.getEyePos(), other.getBoundingBox()));
            if (d < distance) { distance = d; best = other; }
        }
        return best;
    }
    private static boolean validTarget(ClientPlayerEntity self, PlayerEntity other) {
        if (other == null || other == self || !other.isAlive() || other.isSpectator() || other.isCreative() || self.isTeammate(other) || !self.canSee(other)) return false;
        double reach = Math.min(3, self.getEntityInteractionRange());
        return self.getEyePos().squaredDistanceTo(closestPoint(self.getEyePos(), other.getBoundingBox())) <= reach * reach;
    }
    private void hit(MinecraftClient client, ClientPlayerEntity self, PlayerEntity target, long now) {
        Vec3d eye = self.getEyePos(), direction = closestPoint(eye, target.getBoundingBox()).subtract(eye);
        if (direction.lengthSquared() < 1.0E-8) direction = target.getBoundingBox().getCenter().subtract(eye);
        AimMath.Angles aim = AimMath.facing(direction.x, direction.y, direction.z);
        // Local yaw, pitch, body, velocity and movement inputs are never changed.
        float yaw = self.getYaw(), pitch = self.getPitch();
        try {
            sendLook(self, aim.yaw(), aim.pitch());
            client.interactionManager.attackEntity(self, target);
            self.swingHand(Hand.MAIN_HAND);
            nextAttack = now + AttackPolicy.intervalMillis(config.maxCps);
        } finally { sendLook(self, yaw, pitch); }
    }
    private void setSlot(ClientPlayerEntity self, int slot) {
        self.getInventory().selectedSlot = slot;
        self.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        expectedSlot = slot;
    }
    private void cancel(ClientPlayerEntity self) {
        int current = self.getInventory().selectedSlot;
        int restore = AttackPolicy.slotAfterCancel(originalSlot, expectedSlot, current);
        if (restore != current) setSlot(self, restore);
        clearSequence();
    }
    private void clearSequence() { stage = Stage.IDLE; originalSlot = expectedSlot = maceSlot = -1; pendingTarget = null; combo = false; }
    private static Vec3d closestPoint(Vec3d eye, Box box) {
        return new Vec3d(AimMath.clamp(eye.x, box.minX, box.maxX), AimMath.clamp(eye.y, box.minY, box.maxY), AimMath.clamp(eye.z, box.minZ, box.maxZ));
    }
    private static void sendLook(ClientPlayerEntity self, float yaw, float pitch) {
        self.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, self.isOnGround(), self.horizontalCollision));
    }
}
