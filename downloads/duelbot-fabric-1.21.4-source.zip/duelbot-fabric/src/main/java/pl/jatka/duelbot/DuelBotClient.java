package pl.jatka.duelbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public final class DuelBotClient implements ClientModInitializer {
    private boolean enabled;
    private KeyBinding toggle;

    @Override
    public void onInitializeClient() {
        toggle = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Private Duel Bot: wlacz / wylacz", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R, "Private Duel Bot"));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> enabled = false);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(MinecraftClient client) {
        ClientPlayerEntity self = client.player;
        if (self == null || client.world == null || client.interactionManager == null) {
            enabled = false;
            return;
        }
        while (toggle.wasPressed()) {
            enabled = !enabled;
            self.sendMessage(Text.literal("Duel Bot: " + (enabled ? "ON" : "OFF")), true);
        }
        if (!enabled || client.currentScreen != null || client.isPaused()
                || !self.isAlive() || self.isSpectator() || self.isUsingItem()
                || self.getAttackCooldownProgress(0.0F) < 1.0F) return;

        Vec3d eye = self.getEyePos();
        double reach = Math.min(3.0, self.getEntityInteractionRange());
        double bestDistance = reach * reach;
        PlayerEntity target = null;
        for (PlayerEntity other : client.world.getPlayers()) {
            if (other == self || !other.isAlive() || other.isSpectator()
                    || other.isCreative() || self.isTeammate(other) || !self.canSee(other)) continue;
            double distance = eye.squaredDistanceTo(closestPoint(eye, other.getBoundingBox()));
            if (distance <= bestDistance) {
                bestDistance = distance;
                target = other;
            }
        }
        if (target != null) attack(client, self, target, eye);
    }

    private static Vec3d closestPoint(Vec3d eye, Box box) {
        return new Vec3d(AimMath.clamp(eye.x, box.minX, box.maxX),
                AimMath.clamp(eye.y, box.minY, box.maxY),
                AimMath.clamp(eye.z, box.minZ, box.maxZ));
    }

    private static void attack(MinecraftClient client, ClientPlayerEntity self,
                               PlayerEntity target, Vec3d eye) {
        Vec3d point = closestPoint(eye, target.getBoundingBox());
        Vec3d direction = point.subtract(eye);
        if (direction.lengthSquared() < 1.0E-8) {
            direction = target.getBoundingBox().getCenter().subtract(eye);
        }
        AimMath.Angles aim = AimMath.facing(direction.x, direction.y, direction.z);
        float yaw = self.getYaw(), pitch = self.getPitch(), head = self.getHeadYaw();
        float body = self.bodyYaw;
        try {
            self.setYaw(aim.yaw());
            self.setPitch(aim.pitch());
            self.setHeadYaw(aim.yaw());
            self.bodyYaw = aim.yaw();
            sendLook(self, aim.yaw(), aim.pitch());
            // The normal client attack path: no /damage, chat commands, or datapack.
            client.interactionManager.attackEntity(self, target);
            self.swingHand(Hand.MAIN_HAND);
        } finally {
            self.setYaw(yaw);
            self.setPitch(pitch);
            self.setHeadYaw(head);
            self.bodyYaw = body;
            sendLook(self, yaw, pitch);
        }
    }

    private static void sendLook(ClientPlayerEntity self, float yaw, float pitch) {
        self.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, pitch, self.isOnGround(), self.horizontalCollision));
    }
}
