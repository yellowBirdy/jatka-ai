package pl.jatka.duelbot;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import java.util.*;

final class DuelSettingsScreen extends Screen {
    private final Screen parent;
    private final DuelConfig config;
    private final boolean items;
    private int page;
    DuelSettingsScreen(Screen parent, DuelConfig config, boolean items) {
        super(Text.literal(items ? "Duel Bot — przedmioty" : "Duel Bot — ustawienia"));
        this.parent = parent; this.config = config; this.items = items;
    }
    private static String state(boolean v) { return v ? "ON" : "OFF"; }
    private void button(String label, int y, Runnable action) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> action.run())
                .dimensions(width / 2 - 150, y, 300, 20).build());
    }
    private void change(Runnable change) { change.run(); config.save(); clearAndInit(); }
    @Override protected void init() {
        int y = 45;
        if (items) {
            List<String> entries = new ArrayList<>();
            for (String n : DuelConfig.WEAPONS) entries.add("minecraft:" + n);
            if (client != null && client.player != null) {
                String held = Registries.ITEM.getId(client.player.getMainHandStack().getItem()).toString();
                if (!entries.contains(held)) entries.add(held);
            }
            int rows = Math.max(2, Math.min(6, (height - 140) / 24));
            int pages = (entries.size() + rows - 1) / rows;
            page = Math.min(page, pages - 1);
            for (int i = page * rows; i < Math.min(entries.size(), page * rows + rows); i++) {
                String id = entries.get(i);
                button(id + ": " + state(config.allowedItems.contains(id)), y, () -> change(() -> {
                    if (!config.allowedItems.remove(id)) config.allowedItems.add(id);
                }));
                y += 24;
            }
            button("Strona " + (page + 1) + "/" + pages + " — nastepna", y + 4, () -> { page = (page + 1) % pages; clearAndInit(); });
            button("Wszystkie / zadne", y + 28, () -> change(() -> {
                if (config.allowedItems.containsAll(entries)) config.allowedItems.clear(); else config.allowedItems.addAll(entries);
            }));
            y += 56;
        } else {
            button("Przedmioty dozwolone...", y, () -> client.setScreen(new DuelSettingsScreen(this, config, true))); y += 24;
            button("Maks. ataki/s: " + config.maxCps + " (kliknij +1)", y, () -> change(() -> config.maxCps = config.maxCps % 20 + 1)); y += 24;
            button("Zwykle ataki: pelne odnowienie: " + state(config.respectCooldown), y, () -> change(() -> config.respectCooldown = !config.respectCooldown)); y += 24;
            button("Shield break (topor z paska): " + state(config.shieldBreak), y, () -> change(() -> config.shieldBreak = !config.shieldBreak)); y += 24;
            button("Stun slam (elytra, topor, mace): " + state(config.stunSlam), y, () -> change(() -> config.stunSlam = !config.stunSlam)); y += 24;
            button("Przerwa topor -> mace: " + config.maceDelayTicks + " tick", y, () -> change(() -> config.maceDelayTicks = config.maceDelayTicks % 10 + 1)); y += 30;
        }
        button("Gotowe", Math.min(y + 12, height - 28), this::close);
    }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0xE0151922);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 18, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }
    @Override public boolean shouldPause() { return false; }
    @Override public void close() { config.save(); client.setScreen(parent); }
}
