package pl.jatka.duelbot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

final class DuelConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("duelbot.json");
    static final List<String> WEAPONS = List.of(
            "wooden_sword", "stone_sword", "iron_sword", "golden_sword", "diamond_sword", "netherite_sword",
            "wooden_axe", "stone_axe", "iron_axe", "golden_axe", "diamond_axe", "netherite_axe", "mace");
    int maxCps = 8;
    boolean respectCooldown = true;
    boolean shieldBreak = false;
    boolean stunSlam = false;
    int maceDelayTicks = 2;
    Set<String> allowedItems = new LinkedHashSet<>();
    DuelConfig() { for (String name : WEAPONS) allowedItems.add("minecraft:" + name); }
    static DuelConfig load() {
        if (Files.exists(FILE)) {
            try {
                DuelConfig c = GSON.fromJson(Files.readString(FILE), DuelConfig.class);
                if (c != null) {
                    c.maxCps = AttackPolicy.boundedCps(c.maxCps);
                    c.maceDelayTicks = AttackPolicy.boundedDelay(c.maceDelayTicks);
                    if (c.allowedItems == null) c.allowedItems = new LinkedHashSet<>();
                    c.allowedItems.removeIf(Objects::isNull);
                    return c;
                }
            } catch (IOException | RuntimeException e) { LoggerFactory.getLogger("duelbot").warn("Cannot load duelbot.json; using defaults", e); }
        }
        return new DuelConfig();
    }
    void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Path temporary = Files.createTempFile(FILE.getParent(), "duelbot-", ".tmp");
            Files.writeString(temporary, GSON.toJson(this));
            try { Files.move(temporary, FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ignored) { Files.move(temporary, FILE, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) { LoggerFactory.getLogger("duelbot").warn("Cannot save duelbot.json", e); }
    }
}
