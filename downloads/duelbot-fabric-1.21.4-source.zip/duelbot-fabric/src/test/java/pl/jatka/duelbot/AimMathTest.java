package pl.jatka.duelbot;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
final class AimMathTest {
    @Test void facesMinecraftCardinalDirections() {
        assertEquals(0, AimMath.facing(0, 0, 1).yaw(), .001);
        assertEquals(-90, AimMath.facing(1, 0, 0).yaw(), .001);
        assertEquals(90, AimMath.facing(-1, 0, 0).yaw(), .001);
    }
    @Test void looksUpAndDownWithoutInvalidAngles() {
        assertEquals(-90, AimMath.facing(0, 1, 0).pitch(), .001);
        assertEquals(90, AimMath.facing(0, -1, 0).pitch(), .001);
        assertTrue(Float.isFinite(AimMath.facing(0, 0, 0).pitch()));
    }
    @Test void clampsToTheTargetHitbox() {
        assertEquals(2, AimMath.clamp(9, 1, 2));
        assertEquals(1, AimMath.clamp(-9, 1, 2));
        assertEquals(1.5, AimMath.clamp(1.5, 1, 2));
    }
}
