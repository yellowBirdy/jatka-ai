package pl.jatka.duelbot;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
final class AttackPolicyTest {
    @Test void attackRateIsBoundedAndNeverEarlierThanRequested() {
        assertEquals(1000, AttackPolicy.intervalMillis(0));
        assertEquals(50, AttackPolicy.intervalMillis(999));
        assertEquals(125, AttackPolicy.intervalMillis(8));
        assertFalse(AttackPolicy.ready(124,125,1,true));
        assertFalse(AttackPolicy.ready(125,125,.9f,true));
        assertTrue(AttackPolicy.ready(125,125,1,true));
        assertTrue(AttackPolicy.ready(125,125,.2f,false));
    }
    @Test void cancellationRestoresAutomaticSwapsButPreservesManualSelection() {
        assertEquals(2, AttackPolicy.slotAfterCancel(2, 4, 4));
        assertEquals(6, AttackPolicy.slotAfterCancel(2, 4, 6));
        assertEquals(5, AttackPolicy.slotAfterCancel(-1, -1, 5));
    }
    @Test void slamOnlyStartsDuringDescentWithElytra() {
        assertTrue(AttackPolicy.fallingSlam(true,false,-.2));
        assertFalse(AttackPolicy.fallingSlam(false,false,-.2));
        assertFalse(AttackPolicy.fallingSlam(true,true,-.2));
        assertFalse(AttackPolicy.fallingSlam(true,false,.2));
        assertEquals(1,AttackPolicy.boundedDelay(0));
        assertEquals(10,AttackPolicy.boundedDelay(500));
    }
}
