@echo off
cd /d "%~dp0"
call gradlew.bat --no-daemon build
if errorlevel 1 (
 echo Blad kompilacji. Wymagany JDK 21 i dostep do internetu.
 pause
 exit /b 1
)
explorer "build\libs"
pause
